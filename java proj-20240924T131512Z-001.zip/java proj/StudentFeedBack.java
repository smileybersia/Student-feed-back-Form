

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = {"/StudentFeedBack"})


 public class StudentFeedBack extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public StudentFeedBack() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try{
			String dname=request.getParameter("dname");
			String tname=request.getParameter("tname");
			String sub=request.getParameter("sub");
			String a=request.getParameter("a");
			int a1=Integer.parseInt(a);
			String b=request.getParameter("b");
			int b1=Integer.parseInt(b);
			String c=request.getParameter("c");
			int c2=Integer.parseInt(c);
			String d=request.getParameter("d");
			int d2=Integer.parseInt(d);
			String e=request.getParameter("e");
			int e2=Integer.parseInt(e);
			String f=request.getParameter("f");
			int f1=Integer.parseInt(f);
			String g=request.getParameter("g");
			int g1=Integer.parseInt(g);
			String h=request.getParameter("h");
			int h1=Integer.parseInt(h);
			Class.forName("com.mysql.jdbc.Driver");
	 		Connection c1=DriverManager.getConnection("jdbc:mysql://localhost:3306/feedback", "root", "");
			Statement s =c1.createStatement();
			String sql=null;
			String sql2=null;
			ResultSet rs=null;
			int num=0;
			switch(a1)
			{
			case 1:
				sql2="select * from teacherreporta where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreporta set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporta values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreporta where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreporta set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporta values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreporta where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreporta set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporta values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreporta where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreporta set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporta values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(b1)
			{
			case 1:
				sql2="select * from teacherreportb where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreportb set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportb values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreportb where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreportb set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportb values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreportb where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreportb set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportb values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreportb where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreportb set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportb values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(c2)
			{
			case 1:
				sql2="select * from teacherreportc where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreportc set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportc values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreportc where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreportc set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportc values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreportc where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreportc set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportc values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreportc where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreportc set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportc values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(d2)
			{
			case 1:
				sql2="select * from teacherreportd where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreportd set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportd values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreportd where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreportd set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportd values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreportd where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreportd set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportd values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreportd where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreportd set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportd values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(e2)
			{
			case 1:
				sql2="select * from teacherreporte where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreporte set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporte values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreporte where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreporte set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporte values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreporte where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreporte set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporte values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreporte where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreporte set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporte values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(f1)
			{
			case 1:
				sql2="select * from teacherreportf where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreportf set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportf values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreportf where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreportf set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportf values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreportf where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreportf set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportf values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreportf where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreportf set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportf values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(g1)
			{
			case 1:
				sql2="select * from teacherreportg where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreportg set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportg values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreportg where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreportg set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportg values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreportg where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreportg set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportg values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreportg where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreportg set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreportg values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			switch(h1)
			{
			case 1:
				sql2="select * from teacherreporth where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o1")+1;
					sql="update teacherreporth set o1="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporth values('"+dname+"','"+tname+"','"+sub+"',"+num+",0,0,0)";
				}
				break;
			case 2:
				sql2="select * from teacherreporth where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o2")+1;
					sql="update teacherreporth set o2="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporth values('"+dname+"','"+tname+"','"+sub+"',0,"+num+",0,0)";
				}
				break;
			case 3:
				sql2="select * from teacherreporth where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o3")+1;
					sql="update teacherreporth set o3="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporth values('"+dname+"','"+tname+"','"+sub+"',0,0,"+num+",0)";
				}
				break;
			case 4:
				sql2="select * from teacherreporth where tname='"+tname+"'";
				try
				{
					rs=s.executeQuery(sql2);
					rs.next();
					num=rs.getInt("o4")+1;
					sql="update teacherreporth set o4="+num+" where tname='"+tname+"'";
				}catch(SQLException e1)
				{
					num=1;
					sql="insert into teacherreporth values('"+dname+"','"+tname+"','"+sub+"',0,0,0,"+num+")";
				}
				break;
			}
			s.execute(sql);
			
			
		}catch(Exception e){out.println(e);}
		response.sendRedirect("thank.html");
	}   	  	    
}